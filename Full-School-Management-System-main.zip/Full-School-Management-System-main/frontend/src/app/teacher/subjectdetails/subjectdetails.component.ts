import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subjectdetails',
  templateUrl: './subjectdetails.component.html',
  styleUrls: ['./subjectdetails.component.scss']
})
export class SubjectdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
