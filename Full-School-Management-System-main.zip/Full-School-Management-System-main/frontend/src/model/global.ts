// export const BASE_URL = 'http://192.168.43.63:3400/api/v1/en'
export const BASE_URL = 'http://localhost:3400/api/v1/en'
// export const BASE_URL = 'https://68a9d77247c8.ngrok.io/api/v1/en'
