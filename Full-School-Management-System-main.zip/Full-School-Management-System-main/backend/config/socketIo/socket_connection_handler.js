// /**
//  * Created by Raza on 17/8/2017.
//  */

// 'use strict';

// const socketHandler = require('./socketio'),
//     winston = require('../winston');

// const socketConnectInitialization = (server) => {

//     winston.info('Initializing Socket IO Connections');
//     // initializing socket io
//     global.io = require('./io')(server);

//     // socket connection
//     // io.sockets.on('connection', socketHandler);
//     io.on('connection', socketHandler);

// };


// module.exports = {
//     socketConnectInitialization
// };

