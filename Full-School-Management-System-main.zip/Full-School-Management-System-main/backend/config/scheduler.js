const schedule = require('node-schedule');

// Test Function   
// schedule.scheduleJob('0 0 * * *', functionName); // run on every day