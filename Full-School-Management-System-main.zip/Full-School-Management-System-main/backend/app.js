'use strict';

var app = require('./config/express');

module.exports = app;

